<?php
    if ($editing) {
        \Illuminate\Support\Facades\Request::merge($course->toArray());
        \Illuminate\Support\Facades\Request::flash();
    }
?>



<?php $__env->startSection('content'); ?>
    <form action="<?php echo e($editing ? route('admin.courses.update', ['course' => $course->id]) : route('admin.courses.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php if($editing): ?>
            <?php echo method_field('put'); ?>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-md-8 <?php echo e($editing ? '' : 'mx-auto'); ?>">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e($editing ? 'Edit course' : 'Add course'); ?>

                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="title">title</label>
                                <input type="text" name="title" id="title" value="<?php echo e(old('title', $course->title)); ?>" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="formation_id">
                                    <?php echo e(__('Formation')); ?>

                                </label>

                                <select name="formation_id" id="formation_id"
                                    class="form-control <?php $__errorArgs = ['formation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="" <?php if(old('formation_id', $course->formation_id) == null): ?> selected <?php endif; ?>>Aucune formation</option>
                                    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($formation->id); ?>" data-students="<?php echo e($formation->students); ?>"
                                        <?php if(old('formation_id', $course->formation_id) == $formation->id): ?> selected <?php endif; ?>>
                                        <?php echo e($formation->title); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['formation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="user_id">
                                    <?php echo e(__('instructor')); ?>

                                </label>

                                <select name="user_id" id="user_id"
                                    class="form-control <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="" <?php if(old('user_id', $course->user_id) == null): ?> selected <?php endif; ?>>No instructor</option>
                                    <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($instructor->id); ?>" <?php if(old('user_id', $course->user_id) == $instructor->id): ?> selected <?php endif; ?>>
                                        <?php echo e($instructor->full_name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-between">
                                <button class="btn btn-success" type="submit">
                                    <?php echo e($editing ? 'Edit' : 'Add'); ?>

                                </button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($editing): ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            Add courses in the formation
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="students">Choose the students</label>
                                <?php
                                    $students_array = $course->students->pluck('id')->toArray();
                                ?>
                                <select id="students" name="students[]" class="form-control" multiple>
                                    <option value="" disabled>Choisir les students</option>
                                    <?php if($course->formation): ?>
                                        <?php $__currentLoopData = $course->formation->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($student->id); ?>"
                                            <?php if(in_array($student->id, old('students', $students_array))): ?> selected <?php endif; ?>><?php echo e($student->full_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div>
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => $editing ? 'Edit course' : 'Add course'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/admin/courses/showForm.blade.php ENDPATH**/ ?>