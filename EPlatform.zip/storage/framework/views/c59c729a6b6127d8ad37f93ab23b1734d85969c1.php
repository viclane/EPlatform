<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex">
                       Formation list








                        <div class="ml-auto">
                            <a href="<?php echo e(route('admin.formations.create')); ?>" class="btn btn-outline-primary">
                                <i class="fa fa-plus"></i>
                                Add
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-responsive">
                            <thead>
                                <tr>
                                    <th scope="col">Title</th>
                                    <th scope="col">Number of course</th>
                                    <th scope="col">Number of student</th>
                                    <th scope="col" style="width: 25%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($formation->title); ?></td>
                                    <td><?php echo e($formation->courses->count()); ?></td>
                                    <td><?php echo e($formation->students->count()); ?></td>
                                    <td class="pb-2" style="width: 25%;">
                                        <a href="<?php echo e(route('admin.formations.show', ['formation' => $formation->id])); ?>" class="btn btn-primary btn-sm mr-1 mb-1">
                                            <i class="fa fa-eye"></i>
                                            View
                                        </a>
                                        <a href="<?php echo e(route('admin.formations.edit', ['formation' => $formation->id])); ?>" class="btn btn-secondary btn-sm mr-1 mb-1">
                                            <i class="fa fa-pen"></i>
                                            Edit
                                        </a>
                                        <form action="<?php echo e(route('admin.formations.destroy', ['formation' => $formation->id])); ?>" method="POST"
                                              class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm mr-1 mb-1">
                                                <i class="fa fa-trash-alt"></i>
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Formation list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/admin/formations/index.blade.php ENDPATH**/ ?>