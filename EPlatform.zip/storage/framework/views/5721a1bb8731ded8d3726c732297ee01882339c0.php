<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex">
                        List of my courses

                        <div class="col-md-6 ml-auto">
                            <form action="" method="get" class="form-inline">
                                <input type="text" name="query" class="form-control mr-2 mb-2" value="<?php echo e(old('query', $query ?? '')); ?>"/>
                                <button type="submit" class="btn btn-primary mb-2">Search</button>
                            </form>
                        </div>

                        <div class="ml-auto">
                            <a href="<?php echo e(route('students.courses.add')); ?>" class="btn btn-outline-primary">
                                <i class="fa fa-plus"></i>
                                Add
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-responsive">
                            <thead>
                                <tr>
                                    <th scope="col">Name of course</th>
                                    <th scope="col" style="width: 25%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($course->title); ?></td>
                                    <td class="pb-2" style="width: 25%;">
                                        <a href="<?php echo e(route('students.courses.show', ['course' => $course->id])); ?>" class="btn btn-primary btn-sm mr-1 mb-1">
                                            <i class="fa fa-eye"></i>
                                           View
                                        </a>
                                        <a href="<?php echo e(route('students.schedules', ['course_id' => $course->id])); ?>" class="btn btn-secondary btn-sm mr-1 mb-1">
                                            <i class="fa fa-clock"></i>
                                            View a schedule
                                        </a>
                                        <form action="<?php echo e(route('students.courses.update', ['course' => $course->id])); ?>" method="POST"
                                            class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="validate" value="0">
                                            <button type="submit" class="btn btn-danger btn-sm mr-1 mb-1">
                                                <i class="fa fa-power-off"></i>
                                                To unsubscribe
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'List of my courses'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/students/courses.blade.php ENDPATH**/ ?>