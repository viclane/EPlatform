<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header d-flex">
                    User awaiting validation

                    <div class="col-md-6 ml-auto">
                        <form action="" method="get" class="form-inline">
                                <input type="text" name="query" class="form-control mr-2 mb-2" value="<?php echo e(old('query', $query ?? '')); ?>"/>
                                <div class="form-group mr-2 mb-2">
                                    <select class="form-control" name="type">
                                        <option value="" <?php if($type == null): ?> selected <?php endif; ?>>Everybody</option>
                                        <option value="instructor" <?php if($type == 'instructor'): ?> selected <?php endif; ?>>instructors</option>
                                        <option value="student" <?php if($type == 'student'): ?> selected <?php endif; ?>>Students</option>
                                    </select>
                                </div>
                            <button type="submit" class="btn btn-primary mb-2">Search</button>
                        </form>
                    </div>

                    <div class="ml-auto">
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-outline-primary">
                            <i class="fa fa-plus"></i>
                            Add a new user
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Login</th>
                                <th scope="col">Role</th>
                                <th scope="col">Formation</th>
                                <th scope="col" style="width: 25%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->full_name); ?></td>
                                <td><?php echo e($user->login); ?></td>
                                <td><?php echo e($user->formation_id ? 'student' : 'instructor'); ?></td>
                                <td><?php echo e($user->formation ? $user->formation->title : ''); ?></td>
                                <td class="pb-2" style="width: 25%;">
                                    <a href="<?php echo e(route('admin.users.show', ['user' => $user->id])); ?>" class="btn btn-primary btn-sm mr-1 mb-1">
                                        <i class="fa fa-eye"></i>
                                        View
                                    </a>
                                    <form action="<?php echo e(route('admin.users.update', ['user' => $user->id])); ?>" method="POST"
                                          class="d-inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="type" value="<?php echo e($user->formation_id ? 'student' : 'instructor'); ?>"/>
                                        <input type="hidden" name="formation_id" value="<?php echo e($user->formation_id); ?>"/>
                                        <button type="submit" class="btn btn-outline-success btn-sm mr-1 mb-1">
                                            <i class="fa fa-check"></i>
                                            Accept
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('admin.users.destroy', ['user' => $user->id])); ?>" method="POST"
                                        class="d-inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm mr-1 mb-1">
                                            <i class="fa fa-trash-alt"></i>
                                            Refuse
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/admin/users/unvalidate.blade.php ENDPATH**/ ?>