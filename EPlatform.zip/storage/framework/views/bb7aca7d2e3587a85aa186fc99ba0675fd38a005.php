<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex">
                    <?php if($user->id == Auth::user()->id): ?>
                        Mon profle
                        <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-success ml-auto">
                            <i class="fa fa-pen"></i>
                            Editer
                        </a>
                    <?php else: ?>
                    <?php echo e(__('Profile de ') . $user->full_name); ?>

                    <?php endif; ?>
                </div>

                <div class="card-body">
                    Type : <?php echo e($user->type); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/home.blade.php ENDPATH**/ ?>