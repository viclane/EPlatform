<?php
    $myCourses = Auth::user()->courses->pluck('id')->toArray();
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex">
                        Courses list

                        <div class="col-md-6 ml-auto">
                            <form action="" method="get" class="form-inline">
                                <input type="text" name="query" class="form-control mr-2 mb-2" value="<?php echo e(old('query', $query ?? '')); ?>"/>
                                <div class="form-group mr-2 mb-2">
                                    <select class="form-control" name="unsubscribe">
                                        <option value="" <?php if($unsubscribe == null || $unsubscribe == 0): ?> selected <?php endif; ?>>All courses</option>
                                        <option value="1" <?php if($unsubscribe == '1'): ?> selected <?php endif; ?>>
                                        Not enrolled
                                        </option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary mb-2">Search</button>
                            </form>
                        </div>

                        <div class="ml-auto">
                            <a href="<?php echo e(route('students.courses')); ?>" class="btn btn-outline-primary">
                                <i class="fa fa-list"></i>
                                Return to the course's list
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-responsive">
                            <thead>
                                <tr>
                                    <th scope="col">Nom</th>
                                    <th scope="col" style="width: 25%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($course->title); ?></td>
                                    <td class="pb-2" style="width: 25%;">
                                        <a href="<?php echo e(route('students.courses.show', ['course' => $course->id])); ?>" class="btn btn-primary btn-sm mr-1 mb-1">
                                            <i class="fa fa-eye"></i>
                                           View
                                        </a>
                                        <?php if(in_array($course->id, $myCourses)): ?>
                                            <a href="<?php echo e(route('students.schedules', ['course_id' => $course->id])); ?>" class="btn btn-secondary btn-sm mr-1 mb-1">
                                                <i class="fa fa-clock"></i>
                                                View a schedule
                                            </a>
                                        <?php endif; ?>

                                        <form action="<?php echo e(route('students.courses.update', ['course' => $course->id])); ?>" method="POST"
                                            class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <?php if(in_array($course->id, $myCourses)): ?>
                                                <input type="hidden" name="validate" value="0">
                                                <button type="submit" class="btn btn-danger btn-sm mr-1 mb-1">
                                                    <i class="fa fa-power-off"></i>
                                                    To unsubscribe
                                                </button>
                                            <?php else: ?>
                                                <input type="hidden" name="validate" value="1">
                                                <button type="submit" class="btn btn-warning btn-sm mr-1 mb-1">
                                                    <i class="fa fa-sign-in-alt"></i>
                                                    Register
                                                </button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="mt-2">
                            <?php echo e($courses->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Add courses'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viclane Staelle\Desktop\EPlatform\resources\views/students/showFormCourses.blade.php ENDPATH**/ ?>